package game.items;

public class EasyWeapon implements Weapon {
    public String use() {
        return "Using a basic weapon!";
    }
}
