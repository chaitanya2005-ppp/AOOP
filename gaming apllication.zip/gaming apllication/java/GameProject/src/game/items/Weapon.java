package game.items;

public interface Weapon {
    String use();
}
