package game.items;

public interface PowerUp {
    String activate();
}
