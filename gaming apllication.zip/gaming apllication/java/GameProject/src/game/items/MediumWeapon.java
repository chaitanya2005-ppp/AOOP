package game.items;

public class MediumWeapon implements Weapon {
    public String use() {
        return "Using a more powerful weapon!";
    }
}
