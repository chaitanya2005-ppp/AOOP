package Bubblesort;

import java.util.Arrays;

public class BubbleSortDemo {
	public static <T extends Comparable<T>> void bubbleSort(T[] array) {
        int n = array.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j].compareTo(array[j + 1]) > 0) {
                    // Swap array[j] and array[j + 1]
                    T temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no two elements were swapped, the array is sorted
            if (!swapped) break;
        }
    }

    public static void main(String[] args) {
        // Test with integers
        Integer[] intArray = {5, 3, 8, 4, 2};
        System.out.println("Before sorting (Integers): " + Arrays.toString(intArray));
        bubbleSort(intArray);
        System.out.println("After sorting (Integers): " + Arrays.toString(intArray));

        // Test with doubles
        Double[] doubleArray = {3.1, 1.4, 2.9, 0.5};
        System.out.println("\nBefore sorting (Doubles): " + Arrays.toString(doubleArray));
        bubbleSort(doubleArray);
        System.out.println("After sorting (Doubles): " + Arrays.toString(doubleArray));

        // Test with strings
        String[] stringArray = {"apple", "orange", "banana", "grape"};
        System.out.println("\nBefore sorting (Strings): " + Arrays.toString(stringArray));
        bubbleSort(stringArray);
        System.out.println("After sorting (Strings): " + Arrays.toString(stringArray));
    }
}
