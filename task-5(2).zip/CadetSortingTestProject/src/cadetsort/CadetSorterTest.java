package cadetsort;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
class CadetSorterTest {
	@Test
    void testEmptyList() {
        List<String> cadets = Collections.emptyList();
        assertTrue(CadetSorter.isAlphabeticallySorted(cadets), "Empty list should be considered sorted");
    }

    @Test
    void testSingleCadet() {
        List<String> cadets = Collections.singletonList("Alice");
        assertTrue(CadetSorter.isAlphabeticallySorted(cadets), "Single cadet should be considered sorted");
    }

    @Test
    void testSortedCadets() {
        List<String> cadets = Arrays.asList("Alice", "Bob", "Charlie", "David");
        assertTrue(CadetSorter.isAlphabeticallySorted(cadets), "List is already sorted");
    }

    @Test
    void testUnsortedCadets() {
        List<String> cadets = Arrays.asList("Charlie", "Alice", "Bob", "David");
        assertFalse(CadetSorter.isAlphabeticallySorted(cadets), "List is not sorted");
    }

    @Test
    void testIdenticalNames() {
        List<String> cadets = Arrays.asList("Alice", "Alice", "Bob", "Charlie");
        assertTrue(CadetSorter.isAlphabeticallySorted(cadets), "List with duplicate names should be sorted correctly");
    }

}
