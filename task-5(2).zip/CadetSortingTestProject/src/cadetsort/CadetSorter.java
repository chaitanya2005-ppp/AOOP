package cadetsort;

import java.util.List;

public class CadetSorter {
	public static boolean isAlphabeticallySorted(List<String> cadets) {
        for (int i = 1; i < cadets.size(); i++) {
            if (cadets.get(i - 1).compareTo(cadets.get(i)) > 0) {
                return false; 
            }
        }
        return true; 
    }
}
