/**
 * 
 */
/**
 * 
 */
module CadetSortingTestProject {
	requires org.junit.jupiter.api;
}