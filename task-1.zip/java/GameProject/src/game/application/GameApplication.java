package game.application;

import game.state.GameState;
import game.enemies.Enemy;
import game.enemies.EnemyFactory;
import game.factories.AbstractFactory;
import game.factories.EasyLevelFactory;
import game.factories.MediumLevelFactory;
import game.factories.HardLevelFactory;
import game.items.PowerUp;
import game.items.Weapon;

public class GameApplication {
    public static void main(String[] args) {
        GameState gameState = GameState.getInstance();
        gameState.setLevel(2);
        gameState.setDifficulty("Medium");

        // Creating an enemy based on difficulty
        Enemy enemy = EnemyFactory.createEnemy(gameState.getDifficulty());
        System.out.println(enemy.attack());

        // Creating weapons and power-ups based on difficulty
        AbstractFactory factory;
        switch (gameState.getDifficulty()) {
            case "Easy":
                factory = new EasyLevelFactory();
                break;
            case "Medium":
                factory = new MediumLevelFactory();
                break;
            case "Hard":
                factory = new HardLevelFactory();
                break;
            default:
                throw new IllegalArgumentException("Invalid difficulty");
        }

        Weapon weapon = factory.createWeapon();
        PowerUp powerUp = factory.createPowerUp();

        System.out.println(weapon.use());
        System.out.println(powerUp.activate());
    }
}
