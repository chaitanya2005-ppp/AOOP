package game.enemies;

public interface Enemy {
    String attack();
}
