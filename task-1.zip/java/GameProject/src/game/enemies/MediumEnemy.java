package game.enemies;

public class MediumEnemy implements Enemy {
    public String attack() {
        return "Medium Enemy attacks with moderate damage!";
    }
}
